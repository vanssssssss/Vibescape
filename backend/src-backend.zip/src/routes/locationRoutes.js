const express = require("express");
const router = express.Router();
const { geocodeLocation } = require("../controllers/locationController");

router.post("/geocode", geocodeLocation);

module.exports = router;