const axios = require("axios");

// Convert text location → lat/lng
exports.geocodeLocation = async (req, res) => {
  try {
    const { query } = req.body;

    if (!query) {
      return res.status(400).json({ error: "Location query is required" });
    }

    const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(query)}&format=json&limit=1`;

    const response = await axios.get(url, {
      headers: {
        "User-Agent": "your-app-name" // Required by Nominatim
      }
    });

    if (response.data.length === 0) {
      return res.status(404).json({ error: "Location not found" });
    }

    const location = response.data[0];

    res.json({
      lat: location.lat,
      lng: location.lon,
      displayName: location.display_name
    });

  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Server error" });
  }
};