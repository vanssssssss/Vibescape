import { useEffect, useRef, useCallback } from "react";
import axios from "axios";

export function useProximityWatch({ enabled = true, radius = 500, onNearbyPlace }) {
  const watchId = useRef(null);
  const notifiedIds = useRef(new Set()); // prevent repeat notifications

  const check = useCallback(async ({ coords }) => {
    const { latitude, longitude } = coords;
    const res = await axios.get("/api/location/nearby", {
      params: { lat: latitude, lng: longitude, radius }
    });
    for (const place of res.data.places) {
      if (!notifiedIds.current.has(place.place_id)) {
        notifiedIds.current.add(place.place_id);
        onNearbyPlace(place);
      }
    }
  }, [radius, onNearbyPlace]);

  useEffect(() => {
    if (!enabled || !navigator.geolocation) return;
    watchId.current = navigator.geolocation.watchPosition(check, null, {
      enableHighAccuracy: true,
      maximumAge: 10000,
    });
    return () => navigator.geolocation.clearWatch(watchId.current);
  }, [enabled, check]);
}